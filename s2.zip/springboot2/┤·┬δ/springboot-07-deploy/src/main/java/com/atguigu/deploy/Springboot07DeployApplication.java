package com.atguigu.deploy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot07DeployApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springboot07DeployApplication.class, args);
	}
}
