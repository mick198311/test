package demo.zookeeper.remoting.server;

import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.util.concurrent.CountDownLatch;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.ZooKeeper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import demo.zookeeper.remoting.common.Constant;

public class ServiceProvider {
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceProvider.class);
	
	// 用于等待syncConnected事件触发后继续执行当前线程
	private CountDownLatch latch = new CountDownLatch(1);
	
	// 发布RMI服务并注册RMI地址到Zookeeper中
	public void publish(Remote remote, String host, int port) {
		String url = publishService(remote, host, port);
	    if(url!=null) {
	    	ZooKeeper zk = connectServer(); //连接Zookeeper服务器并获取Zookeeper对象
	    	if(zk != null) {
	    		createNode(zk, url); //创建ZNode并将RMI地址放入ZNode上
	    	}
	    }
	}
	
	// 发布RMI服务
	private String publishService(Remote remote, String host, int port) {
		String url = null;
		url = String.format("rmi://%s:%d/%s", host, port, remote.getClass().getName());
		try {
			LocateRegistry.createRegistry(port);
			LOGGER.debug("publish rmi service (url:{})",url);
			Naming.rebind(url, remote);
		} catch (RemoteException | MalformedURLException e) {
			LOGGER.debug("",e);
		}
		return url;
	}
	
	// 连接zookeepere服务器
	private ZooKeeper connectServer() {
		ZooKeeper zk = null;
		try {
			zk = new ZooKeeper(Constant.ZK_CONNECTION_STRING, Constant.ZK_SESSION_TIMEOUT,new Watcher() {
				@Override
				public void process(WatchedEvent event) {
					if(event.getState() == Event.KeeperState.SyncConnected) {
						LOGGER.debug("connected zookeeper");
						latch.countDown(); // 唤醒当前正在执行的线程
					}
				}
			});
			latch.await(); // 使当前线程处于等待状态
		} catch (IOException | InterruptedException e) {
			LOGGER.debug("",e);
		}
		return zk;
	}
	
	// 创建zNode
	private void createNode(ZooKeeper zk, String url) {
		byte[] data = url.getBytes();
		try {
			// ZooDefs.Ids.OPEN_ACL_UNSAFE表示最大权限
			String path = zk.create(Constant.ZK_PROVIDER_PATH, data, ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL_SEQUENTIAL);// 创建一个临时性且有序的ZNode
			LOGGER.debug("create zookeeper node ({} => {})",path,url);
		} catch (KeeperException | InterruptedException e) {
			LOGGER.debug("",e);
		}
	}
}
