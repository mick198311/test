package demo.zookeeper.remoting.server;

import demo.zookeeper.remoting.common.HelloService;

// 2016111505_ZK搭建RMI服务器HA，dubbox就是依赖zookeeper，就是dubbox底层类似以下这些代码，不光支持rmi，还支持http,rpc等协议
public class Server {

	public static void main(String[] args) throws Exception {
//		if(args.length!=2) {
//			System.err.println("please using command: java Server <rmi host> <rmi port>");
//			System.exit(-1);
//		}
//		
//		String host = args[0];
//		int port = Integer.parseInt(args[1]);
		
//		当前rmi服务器的ip和端口
		String host = "192.168.1.101";
		int port = Integer.parseInt("11237");
		ServiceProvider provider = new ServiceProvider();
		
		HelloService helloService = new HelloServiceImpl();
		provider.publish(helloService, host, port);
		
		
		Thread.sleep(Long.MAX_VALUE);
	}

}
