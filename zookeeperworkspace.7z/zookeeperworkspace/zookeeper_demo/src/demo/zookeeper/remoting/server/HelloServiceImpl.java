package demo.zookeeper.remoting.server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import demo.zookeeper.remoting.common.HelloService;

public class HelloServiceImpl extends UnicastRemoteObject implements HelloService{

	protected HelloServiceImpl() throws RemoteException {
	}

	@Override
	public String sayHello(String name) throws RemoteException {
		return String.format("Hello %s", name);
	}
}
