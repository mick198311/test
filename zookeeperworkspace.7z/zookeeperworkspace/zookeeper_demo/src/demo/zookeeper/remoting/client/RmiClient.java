package demo.zookeeper.remoting.client;

import java.rmi.Naming;

import demo.zookeeper.remoting.common.HelloService;
import demo.zookeeper.remoting.server.HelloServiceImpl;

public class RmiClient {

	public static void main(String[] args) throws Exception {
		String url = "rmi://localhost:1098/demo.zookeeper.remoting.server.HelloServiceImpl";
		HelloService helloService = (HelloService)Naming.lookup(url);
		String result = helloService.sayHello("wangfei");
		System.out.println(result);
	}

}
