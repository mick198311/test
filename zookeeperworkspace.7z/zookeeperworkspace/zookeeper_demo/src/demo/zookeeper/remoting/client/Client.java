package demo.zookeeper.remoting.client;

import demo.zookeeper.remoting.common.HelloService;

public class Client {

	public static void main(String[] args) throws Exception {
		ServiceConsumer consumer = new ServiceConsumer();
		// zookeeper测试
		while(true) {
			HelloService helloService = consumer.lookup();
			String result = helloService.sayHello("牛焕青");
			System.out.println(result);
			Thread.sleep(10000);
		}
	}

}
