package demo.zookeeper.remoting.client;

import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import demo.zookeeper.remoting.common.Constant;

public class ServiceConsumer {
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceConsumer.class);
	
	// 用于等待syncConnected事件触发后继续执行当前线程
    private CountDownLatch latch = new CountDownLatch(1);
	
    // 定义一个volatile成员变量，用于保存最新的RMI地址（考虑到该变量或许会被其他线程所修改，一旦修改后，该变量的值
    // volatile让变量每次在使用的时候，都从主存中取，而不是从各个线程的“工作内存”
    // volatile是具有synchronized关键字的“可见性”，但是没有synchronized关键字的“并发正确性”，也就是说不保证线程安全
    // 也就是说，volatile变量对于每次使用，线程都能得到当前volatile变量的最新值，但是volatile变量并不保证并发的正确性
	private volatile List<String> urlList = new ArrayList<>();
	
	// 构造器
	public ServiceConsumer() {
		ZooKeeper zk = connectServer(); // 连接Zookeeper服务器并获取Zookeeper对象
    	if(zk != null) {
    		watchNode(zk); // 观察/registry节点的所有子节点并更新urlList成员变量
    	}
	}
	
	// 查找RMI服务
	public <T extends Remote> T lookup() {
		T service = null;
		int size = urlList.size();
		if(size > 0) {
			String url;
			if(size == 1) {
				url = urlList.get(0); // 看urlList中只有一个元素，则直接获取该元素
				LOGGER.debug("using only url:{}",url);
				System.out.println(url);
			} else {
				url = urlList.get(ThreadLocalRandom.current().nextInt(size)); // 若urlList中随机取一个
				LOGGER.debug("using random url:{}",url);
				System.out.println(url);
			}
			service = lookupService(url); // 从JNDI中查找RMI服务
		}
		return service;
	}
	
	// 连接zookeepere服务器
	private ZooKeeper connectServer() {
		ZooKeeper zk = null;
		try {
			zk = new ZooKeeper(Constant.ZK_CONNECTION_STRING, Constant.ZK_SESSION_TIMEOUT,new Watcher() {
				@Override
				public void process(WatchedEvent event) {
					if(event.getState() == Event.KeeperState.SyncConnected) {
						LOGGER.debug("connected zookeeper");
						latch.countDown(); // 唤醒当前正在执行的线程
					}
				}
			});
			latch.await(); // 使当前线程处于等待状态
		} catch (IOException | InterruptedException e) {
			LOGGER.debug("",e);
		}
		return zk;
	}
	
	// 观察/registry节点的所有子节点是否有变化
	private void watchNode(final ZooKeeper zk) {
		try {
			List<String> nodeList = zk.getChildren(Constant.ZK_REGISTRY_PATH, new Watcher() {
				@Override
				public void process(WatchedEvent event) {
					if(event.getType() == Event.EventType.NodeChildrenChanged) {
						watchNode(zk); // 若子节点有变化，则重新调用该方法（为了获取最新子节点中的数据）
					}
				}
			});
			List<String> dataList = new ArrayList<>(); // 用于存放/registry所有子节点中的数据
			for (String node : nodeList) {
				byte[] data = zk.getData(Constant.ZK_REGISTRY_PATH+"/"+node, false, null);
				dataList.add(new String(data));
			}
			LOGGER.debug("node data:{}",dataList);
			urlList = dataList; // 更新最新的RMI地址
		} catch (KeeperException | InterruptedException e) {
			LOGGER.debug("",e);
		}
	}
	
	private <T extends Remote> T lookupService(String url) {
		T helloService = null;
		try {
			helloService = (T)Naming.lookup(url);
		} catch (MalformedURLException | RemoteException | NotBoundException e) {
			LOGGER.debug("",e);
		}
		return helloService;
	}
}
