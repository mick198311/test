package lockjk;

public interface DoTemplate {
	public void dodo();
}
