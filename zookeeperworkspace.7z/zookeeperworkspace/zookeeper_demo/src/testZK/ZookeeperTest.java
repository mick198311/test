package testZK;

import java.io.IOException;

import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;
import org.junit.After;
import org.junit.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import demo.zookeeper.remoting.common.Constant;

public class ZookeeperTest {
	
	private static final int SESSION_TIMEOUT = 30000;
	
	public static final Logger LOGGER = LoggerFactory.getLogger(ZookeeperTest.class);
	
	private Watcher watcher = new Watcher() {
		@Override
		public void process(WatchedEvent event) {
			LOGGER.info("process："+event.getType());
		}
	};
	
	private ZooKeeper zooKeeper;
	
	@Before
	public void connect() throws IOException {
		zooKeeper = new ZooKeeper(Constant.ZK_CONNECTION_STRING, Constant.ZK_SESSION_TIMEOUT,watcher);
	}
	
	@After
	public void close() {
		try {
			zooKeeper.close();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
