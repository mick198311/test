package com.atguigu.jdk;

public class Builder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder stringBuilder = new StringBuilder("hello,world");
		System.out.println(stringBuilder);
	}

}
