package com.atguigu.proxy.dynamic;

//�ӿ�
public interface ITeacherDao {

	void teach(); // �ڿη���
	void sayHello(String name);
}
