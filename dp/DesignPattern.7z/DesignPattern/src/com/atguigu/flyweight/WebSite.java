package com.atguigu.flyweight;

public abstract class WebSite {

	public abstract void use(User user);//���󷽷�
}
