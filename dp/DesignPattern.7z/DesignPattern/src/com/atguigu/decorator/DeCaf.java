package com.atguigu.decorator;

public class DeCaf extends Coffee {

	public DeCaf() {
		setDes(" ���򿧷� ");
		setPrice(1.0f);
	}
}
