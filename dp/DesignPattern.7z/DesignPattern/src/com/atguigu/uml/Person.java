package com.atguigu.uml;

public class Person{ //������ʽ->��ͼ
	private Integer id;
	private String name;
	public void setName(String name){
		this.name=name;
	}
	public String getName(){
		return  name;
	}
}

