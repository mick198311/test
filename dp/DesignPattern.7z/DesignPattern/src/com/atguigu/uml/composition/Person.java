package com.atguigu.uml.composition;

public class Person {
    private IDCard card; //�ۺϹ�ϵ
    private Head head = new Head(); //��Ϲ�ϵ

}
