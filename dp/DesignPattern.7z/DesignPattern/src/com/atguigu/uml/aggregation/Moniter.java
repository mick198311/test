package com.atguigu.uml.aggregation;

public class Moniter {

}
