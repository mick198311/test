package com.atguigu.strategy.improve;

public class GoodFlyBehavior implements FlyBehavior {

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println(" ���輼���߳� ~~~");
	}

}
