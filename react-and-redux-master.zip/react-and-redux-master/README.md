# react-and-redux

《深入浅出React和Redux》已近由机械工业出版社发行，这个repo存放的是书中所有的代码。

配合React和Redux的持续讨论，作者开通了一个知乎专栏[《进击的React》](https://zhuanlan.zhihu.com/advancing-react)，欢迎关注。对React和Redux技术有问题可以[通过私信或者值乎咨询](https://www.zhihu.com/zhi/people/828707098316656640)，有问必答。

[京东](http://item.jd.com/12073933.html)（这个链接里有书的目录）

[亚马逊](https://www.amazon.cn/%E6%B7%B1%E5%85%A5%E6%B5%85%E5%87%BAReact%E5%92%8CRedux-%E7%A8%8B%E5%A2%A8/dp/B072BM636Z/ref=sr_1_1?ie=UTF8&qid=1494646329&sr=8-1&keywords=%E6%B7%B1%E5%85%A5%E6%B5%85%E5%87%BAreact%E5%92%8Credux)

[当当网](http://product.dangdang.com/25072226.html)

![cover_high](https://cloud.githubusercontent.com/assets/239291/25560742/c3199d9a-2d8e-11e7-81a9-4e11c518e512.jpg)



