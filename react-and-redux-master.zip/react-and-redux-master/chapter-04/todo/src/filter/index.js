import * as actions from './actions.js';
import reducer from './reducer.js';
import view from './views/filters.js';

export {actions, reducer, view};
