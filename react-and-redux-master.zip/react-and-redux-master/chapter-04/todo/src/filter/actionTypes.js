export const SET_FILTER = 'FILTER/SET';
