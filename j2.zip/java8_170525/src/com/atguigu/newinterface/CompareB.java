package com.atguigu.newinterface;

public interface CompareB {
	
	public default void method3(){
		System.out.println("CompareB:深圳");
	}
}
