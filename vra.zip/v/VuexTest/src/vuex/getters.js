/*
包含n个基于state的getter计算属性方法的对象模块
 */
export default {

}