/*
包含n个mutation名称常量
 */
export const REQUESTING = 'requesting' // 请求中
export const REQUEST_SUCCESS = 'request_success' // 请求成功
export const REQUEST_ERROR = 'request_error' // 请求失败


