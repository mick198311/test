package com.atguigu.java8;

public class MyClass {
	
	public String getName(){
		return "嘿嘿嘿";
	}

}
