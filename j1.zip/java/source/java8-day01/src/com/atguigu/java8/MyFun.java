package com.atguigu.java8;

@FunctionalInterface
public interface MyFun {

	public Integer getValue(Integer num);
	
}
