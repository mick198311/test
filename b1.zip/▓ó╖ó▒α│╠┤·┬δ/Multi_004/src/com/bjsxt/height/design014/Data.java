package com.bjsxt.height.design014;

public interface Data {

	String getRequest();

}
